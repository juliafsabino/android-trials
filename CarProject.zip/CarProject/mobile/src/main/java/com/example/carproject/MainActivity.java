package com.example.carproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button speedpedal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        speedpedal = findViewById(R.id.button);
        setMenu(speedpedal);
    }
    public void setMenu(Button speedpedal) {
        System.out.println("lala");
    }
}