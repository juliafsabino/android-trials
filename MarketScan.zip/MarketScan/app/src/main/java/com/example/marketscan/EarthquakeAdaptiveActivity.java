package com.example.marketscan;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.marketscan.R;

public class EarthquakeAdaptiveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onCheckIntensity(View view) {
        EditText intensityEditText = findViewById(R.id.editTextIntensity);
        TextView resultTextView = findViewById(R.id.textViewResult);

        int intensity = Integer.parseInt(intensityEditText.getText().toString());
        adaptToEarthquake(intensity, resultTextView);
    }

    private static void adaptToEarthquake(int intensity, TextView resultTextView) {
        resultTextView.setText("Executing adaptive code...");

        if (intensity >= 7) {
            evacuateBuilding(resultTextView);
        } else if (intensity >= 5) {
            takePrecautions(resultTextView);
        } else {
            carryOn(resultTextView);
        }

        resultTextView.append("\nAdaptive code execution complete.");
    }

    private static void evacuateBuilding(TextView resultTextView) {
        resultTextView.append("\nEvacuating building! Seek safety immediately!");
    }

    private static void takePrecautions(TextView resultTextView) {
        resultTextView.append("\nTaking precautions. Stay alert and be prepared.");
    }

    private static void carryOn(TextView resultTextView) {
        resultTextView.append("\nNo immediate threat detected. Carry on with normal activities.");
    }
}
